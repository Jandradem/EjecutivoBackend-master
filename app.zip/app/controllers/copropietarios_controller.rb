class CopropietariosController < ApplicationController
  before_action :set_copropietario, only: [:show, :edit, :update, :destroy]
  skip_before_filter :verify_authenticity_token

  # GET /copropietarios
  def index
    @copropietarios = Copropietario.all
    render :json => @copropietarios
  end

  # GET /copropietarios/1
  def show
    @indicador = Indicador.all
    render :json => @indicador
  end

  # POST /copropietarios
  def create
    @copropietario = Copropietario.new(copropietario_params)
    if @copropietario.save
      render { render action: 'show', status: :created, location: @copropietario }
    else
      render { render json: @copropietario.errors, status: :unprocessable_entity }
    end
  end

  # PATCH/PUT /copropietarios/1
  def update
    respond_to do |format|
      if @copropietario.update(copropietario_params)
        format.html { redirect_to @copropietario, notice: 'Copropietario was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @copropietario.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /copropietarios/1
  def destroy
    @copropietario.destroy
    respond_to do |format|
      format.html { redirect_to copropietarios_url }
      format.json { head :no_content }
    end
  end

  def find
    Copropietario.find(params[:id])
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_copropietario
      @copropietario = Copropietario.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def copropietario_params
      params[:copropietario]
    end
end
