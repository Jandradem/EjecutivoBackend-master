class TipoCondominiosController < ApplicationController
  before_action :set_tipo_condominio, only: [:show, :edit, :update, :destroy]

  # GET /tipo_condominios
  # GET /tipo_condominios.json
  def index
    @tipo_condominios = TipoCondominio.all
  end

  # GET /tipo_condominios/1
  # GET /tipo_condominios/1.json
  def show
  end

  # GET /tipo_condominios/new
  def new
    @tipo_condominio = TipoCondominio.new
  end

  # GET /tipo_condominios/1/edit
  def edit
  end

  # POST /tipo_condominios
  # POST /tipo_condominios.json
  def create
    @tipo_condominio = TipoCondominio.new(tipo_condominio_params)

    respond_to do |format|
      if @tipo_condominio.save
        format.html { redirect_to @tipo_condominio, notice: 'Tipo condominio was successfully created.' }
        format.json { render action: 'show', status: :created, location: @tipo_condominio }
      else
        format.html { render action: 'new' }
        format.json { render json: @tipo_condominio.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /tipo_condominios/1
  # PATCH/PUT /tipo_condominios/1.json
  def update
    respond_to do |format|
      if @tipo_condominio.update(tipo_condominio_params)
        format.html { redirect_to @tipo_condominio, notice: 'Tipo condominio was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @tipo_condominio.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /tipo_condominios/1
  # DELETE /tipo_condominios/1.json
  def destroy
    @tipo_condominio.destroy
    respond_to do |format|
      format.html { redirect_to tipo_condominios_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tipo_condominio
      @tipo_condominio = TipoCondominio.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def tipo_condominio_params
      params.require(:tipo_condominio).permit(:idTipoCond, :nombreTipoCond, :estatusTipoCond)
    end
end
