class IndicadoresController < ApplicationController
	before_action :set_indicador, only: [:show, :edit, :update, :destroy]

	#GET /indicadores
	def index
		@indicadores = Indicador.all
		render :json => @indicadores
	end

	#GET /indicadores/1
	def show
		render :json => @indicador
	end

	#POST /indicadores
	def create
		@indicador = Indicador.new(indicador_params)
		if @indicador.save
		  render :json => @indicador
		else
		  render :json => @indicador.errors, status: :unprocessable_entity
		end
	end

	#PATCH/PUT /indicadores/1
	def update
	  if @indicador.update(indicador_params)
	  	render :json => @indicador
	  else
	  	render json: @indicador.errors, status: :unprocessable_entity
	  end
	end

	#DELETE /indicadores/1
	def destroy
		@indicador.destroy
		render :json => '{"estatus": "ok"}'
	end

  private
	  # Use callbacks to share common setup or constraints between actions.
	  def set_indicador
	    @indicador = Indicador.find(params[:id])
	  end

	  # Never trust parameters from the scary internet, only allow the white list through.
	  def indicador_params
	  	params.require(:indicador).permit!
	  end
end