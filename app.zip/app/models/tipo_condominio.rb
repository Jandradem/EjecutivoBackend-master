class TipoCondominio < ActiveRecord::Base
	#self.table_name = "TipoCondominios"
	#self.primary_key = "idTipoCond"
end
