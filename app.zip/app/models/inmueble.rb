class Inmueble < ActiveRecord::Base
	#self.primary_key = "idCopropietario"
	#validates :idCopropietario, :presence => true
	belongs_to :copropietario
end