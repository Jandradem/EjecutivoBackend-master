class Rol < ActiveRecord::Base
	#has_many :indicadores, foreign_key: "rol"
	has_many :indicadores, :class_name => "Indicador", :foreign_key => "rol"
end