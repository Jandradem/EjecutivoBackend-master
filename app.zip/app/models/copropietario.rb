class Copropietario < ActiveRecord::Base
	#self.primary_key = "idCopropietario"
	#validates :idCopropietario, :presence => true
	has_many :inmuebles, foreign_key: "idcopropietario"
end
