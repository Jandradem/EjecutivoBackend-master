class Indicador < ActiveRecord::Base
	self.table_name = "indicadores"
	belongs_to :rol, :class_name => "Rol",  foreign_key: "idrol"
end